import { Phone, MessageCircle, Award, ShieldCheck, Star } from "lucide-react";
import { PHONE_PRIMARY, wa } from "@/lib/constants";
import type { Translations } from "@/lib/types";

export function Hero({ L }: { L: Translations }) {
  return (
    <header
      id="home"
      style={{
        position: "relative",
        paddingTop: 116,
        paddingBottom: 72,
        overflow: "hidden",
        background:
          "linear-gradient(158deg, #0a2135 0%, #0f2d4a 40%, #0d2744 75%, #0a1e36 100%)",
      }}
    >
      {/* Subtle grid overlay */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 0.2,
          backgroundImage:
            "linear-gradient(rgba(255,255,255,.06) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.06) 1px, transparent 1px)",
          backgroundSize: "52px 52px",
          maskImage: "radial-gradient(ellipse at 50% 0%, #000 15%, transparent 70%)",
        }}
      />

      {/* Radial glow */}
      <div
        style={{
          position: "absolute",
          top: "5%",
          left: "50%",
          transform: "translateX(-50%)",
          width: 700,
          height: 500,
          borderRadius: "50%",
          background:
            "radial-gradient(ellipse, rgba(201,162,39,0.09) 0%, rgba(15,45,74,0.05) 50%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      {/* Glow blob bottom-right */}
      <div
        style={{
          position: "absolute",
          bottom: -80,
          insetInlineEnd: -80,
          width: 400,
          height: 400,
          borderRadius: "50%",
          background: "radial-gradient(circle, rgba(45,184,114,0.06) 0%, transparent 70%)",
          pointerEvents: "none",
        }}
      />

      <div
        style={{
          position: "relative",
          maxWidth: 900,
          margin: "0 auto",
          padding: "0 20px",
          textAlign: "center",
        }}
      >
        {/* Eyebrow badge */}
        <div
          className="rise"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "7px 18px",
            borderRadius: 999,
            background: "rgba(201,162,39,0.1)",
            border: "1px solid rgba(201,162,39,0.25)",
            color: "rgba(255,255,255,.92)",
            fontWeight: 700,
            fontSize: 13,
            marginBottom: 26,
            letterSpacing: "0.02em",
          }}
        >
          <Award size={14} color="var(--gold-2)" strokeWidth={2} />
          {L.heroEyebrow}
        </div>

        <h1
          className="rise"
          style={{
            animationDelay: ".07s",
            fontSize: "clamp(34px, 6vw, 60px)",
            fontWeight: 900,
            color: "#fff",
            lineHeight: 1.1,
            margin: 0,
            letterSpacing: "-0.03em",
          }}
        >
          {L.heroTitle1}
          <br />
          <span
            style={{
              color: "var(--gold-2)",
              fontWeight: 900,
            }}
          >
            {L.heroTitle2}
          </span>
        </h1>

        <p
          className="rise"
          style={{
            animationDelay: ".14s",
            maxWidth: 560,
            margin: "22px auto 0",
            fontSize: "clamp(14px, 2vw, 17px)",
            color: "rgba(255,255,255,.68)",
            lineHeight: 1.85,
            fontWeight: 500,
          }}
        >
          {L.heroSub}
        </p>

        {/* CTA buttons */}
        <div
          className="rise flex items-center justify-center"
          style={{
            animationDelay: ".20s",
            gap: 12,
            marginTop: 36,
            flexWrap: "wrap",
          }}
        >
          <a
            href={wa(L.heroMsg)}
            target="_blank"
            rel="noreferrer"
            className="btn-primary"
            style={{ padding: "15px 30px", fontSize: 15, borderRadius: 12 }}
          >
            <MessageCircle size={19} strokeWidth={2} /> {L.heroWa}
          </a>
          <a
            href={`tel:${PHONE_PRIMARY}`}
            className="btn-outline-light"
            style={{ padding: "15px 30px", fontSize: 15, borderRadius: 12 }}
          >
            <Phone size={18} strokeWidth={1.75} /> {L.heroCall}
          </a>
        </div>

        {/* Trust badges */}
        <div
          className="rise flex items-center justify-center"
          style={{
            animationDelay: ".27s",
            gap: 8,
            marginTop: 28,
            flexWrap: "wrap",
          }}
        >
          {L.badges.map((b, i) => (
            <div
              key={i}
              className="flex items-center"
              style={{
                gap: 6,
                padding: "7px 14px",
                borderRadius: 999,
                background: "rgba(255,255,255,.04)",
                border: "1px solid rgba(255,255,255,.1)",
                color: "rgba(255,255,255,.82)",
                fontWeight: 600,
                fontSize: 13,
              }}
            >
              <ShieldCheck size={13} color="var(--gold-2)" strokeWidth={2} /> {b}
            </div>
          ))}
        </div>
      </div>

      {/* Floating Google rating card — desktop only */}
      <div
        data-desktop
        className="fade-in hero-rating-card flex items-center"
        style={{
          position: "absolute",
          bottom: 64,
          insetInlineEnd: "5%",
          background: "rgba(255,255,255,0.06)",
          backdropFilter: "blur(16px)",
          WebkitBackdropFilter: "blur(16px)",
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 16,
          padding: "14px 18px",
          gap: 12,
          animationDelay: ".4s",
        }}
      >
        <div
          className="flex items-center justify-center"
          style={{
            width: 38,
            height: 38,
            borderRadius: 10,
            background: "rgba(201,162,39,0.12)",
            border: "1px solid rgba(201,162,39,0.2)",
            flexShrink: 0,
          }}
        >
          <Star size={18} color="var(--gold-2)" fill="var(--gold-2)" strokeWidth={1.5} />
        </div>
        <div>
          <div
            style={{
              color: "#fff",
              fontWeight: 800,
              fontSize: 15,
              letterSpacing: "-0.01em",
            }}
          >
            5.0 ★★★★★
          </div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11, fontWeight: 600, marginTop: 1 }}>
            {L.heroRating}
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div
        style={{
          position: "absolute",
          bottom: -1,
          insetInlineStart: 0,
          width: "100%",
          height: 52,
          background: "#fff",
          clipPath: "ellipse(72% 100% at 50% 100%)",
        }}
      />
    </header>
  );
}
