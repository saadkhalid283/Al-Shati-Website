import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "الشاطي للتبريد | Al-Shati Cooling",
  description: "إصلاح وصيانة المكيفات والثلاجات والغسالات في جدة",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}