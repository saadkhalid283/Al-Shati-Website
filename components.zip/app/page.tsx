"use client";

import { useState, useEffect } from "react";
import { translations } from "@/lib/translations";
import type { Lang } from "@/lib/types";
import { Navbar } from "@/components/Navbar";
import { Hero } from "@/components/Hero";
import { ServicesSection } from "@/components/ServicesSection";
import { WhySection } from "@/components/WhySection";
import { HowItWorksSection } from "@/components/HowItWorksSection";
import { ReviewsSection } from "@/components/ReviewsSection";
import { ContactSection } from "@/components/ContactSection";
import { Footer } from "@/components/Footer";
import { FloatingWhatsApp } from "@/components/FloatingWhatsApp";
import { TrustBar } from "@/components/TrustBar";
import { CtaSection } from "@/components/CtaSection";

export default function Home() {
  const [lang, setLang] = useState<Lang>("ar");
  const [scrolled, setScrolled] = useState(false);
  const L = translations[lang];
  const isAr = lang === "ar";

  useEffect(() => {
    document.documentElement.dir = L.dir;
    document.documentElement.lang = lang;
  }, [lang, L.dir]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const go = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const siteProps = { lang, L, isAr, go };

  return (
    <div dir={L.dir} className="site-root">
      <Navbar
        L={L}
        scrolled={scrolled}
        onLangToggle={() => setLang(isAr ? "en" : "ar")}
        go={go}
      />
      <Hero L={L} />
      <TrustBar {...siteProps} />
      <ServicesSection {...siteProps} />
      <WhySection {...siteProps} />
      <HowItWorksSection L={L} />
      <ReviewsSection {...siteProps} />
      <ContactSection {...siteProps} />
      <CtaSection L={L} />
      <Footer {...siteProps} />
      <FloatingWhatsApp L={L} />
    </div>
  );
}
